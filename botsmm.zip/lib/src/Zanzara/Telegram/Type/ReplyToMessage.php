<?php

declare(strict_types=1);

namespace Zanzara\Telegram\Type;

/**
 *
 */
class ReplyToMessage extends Message
{

}

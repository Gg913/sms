<?php

namespace Zanzara\Telegram\Type\Input;

abstract class InputMessageContent
{

}
<?php

echo 'Enter';
sleep(3);
echo 'Exit';

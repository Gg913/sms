<?php
date_default_timezone_set("America/Sao_Paulo");

use Zanzara\Zanzara;
use Zanzara\Config;
use Zanzara\Context;

require __DIR__ . '/lib/vendor/autoload.php';
$token = "5904432195:AAFp2kfya7f92X3aYHi3KwJE4IdFsRLP7bA";

$config = new Config();
$config->setParseMode(Config::PARSE_MODE_HTML);
$config->setCacheTtl(240);
$config->setConnectorOptions(['dns' => '8.8.8.8']);

$bot = new Zanzara($token, $config);

include __DIR__ . '/bot.php';
include __DIR__ . '/services.php';
include __DIR__ . '/pix.php';

$bot->onException(function(Context $ctx, $exception) {
	echo "Erro\n";
	echo $exception;
});

$bot->run();
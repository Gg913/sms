<?php

if ($tlg->Callback_ID () !== null){
	
	// encerra carregamento do botão de callback
	$tlg->answerCallbackQuery ([
		'callback_query_id' => $tlg->Callback_ID ()
	]);

}
$id_pagamento = $pagamento ['id'];
$bonus = (BONUS == 0) ? '' : '<em><u>+'.BONUS.'% bônus</u></em>';
$valor_pagamento = 11;

if (isset ($complemento)){

	// pega valor e tipo de calculo
	@list ($valor, $calculo) = explode (' ', $complemento);

	switch ($calculo) {
		case "+1":

		$valor_pagamento = ++$valor;

			break;

		case "+10":

		$valor_pagamento = $valor+10;

			break;

		case "-10":

		$valor_pagamento = $valor-10;

			break;
		
		case "-1":

			case "-50":

				$valor_pagamento = $valor-50;
		
					break;
					case "+50":

						$valor_pagamento = $valor+50;
				
							break;

		$valor_pagamento = --$valor;

			break;
	}

	// checagem de valor abaixo do mínimo
	if ($valor_pagamento < 11){
		$valor_pagamento = 11;
	}

}

$dados_mensagem = [
	'chat_id' => $tlg->ChatID (),
	'text' => "🔹 💰 Pix Manual\nPara adicionar saldo a sua conta, envie um Pix para a seguinte chave:\n\nNome: chame @gringomdz\nChave Pix: chame @gringomdz\n\n\n Após o pagamento, envie o comprovante para @gringomdz\n\n⚠️ Se você enviar um valor MENOR que R$ 11, você perderá o depósito.",
	'parse_mode' => 'html',
	'message_id' => $tlg->MessageID (),
	'disable_web_page_preview' => 'true',
	'reply_markup' => $tlg->buildInlineKeyboard ([
		[
			$tlg->buildInlineKeyBoardButton ("💰Saldo", null, "/saldo"),
                        $tlg->buildInlineKeyBoardButton ("volta", null, "/start")
                 ],
	])
];

if ($tlg->Callback_ID () !== null){

	$tlg->editMessageText ($dados_mensagem);

}else {

	$tlg->sendMessage ($dados_mensagem);

}

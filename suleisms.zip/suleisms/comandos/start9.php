<?php
$bd_tlg->setPais ($tlg->UserID (), $id_pais);
$id_pais = (PAISES [$complemento]) ? $complemento : 73;
	$pais = PAISES [$id_pais];
$saldo = (string)number_format ($user ['saldo'], 2);
$tlg->sendMessage ([
	'chat_id' => $tlg->ChatID (),
	'text' => "😀 <b>Olá ".htmlentities ($tlg->FirstName ())."</b>,  Seja bem-vindo (a)!\n\n😉 Eu Sou Um Bot Feito Para Receber SMS's De Varios Serviços.\n\n🏳️ | Pais Selecionado: {$pais}\n💰 | Seu Saldo:<code> R\${$saldo}</code>\nID carteira: <code>{$tlg->UserID ()}</code>\n\n\nVeja nossos termos /termos\n\n<b><em><a href=\"https://t.me/MDZDONATES\">🏅 · GRUPO</a></em></b>",
	'parse_mode' => 'html',
	'disable_web_page_preview' => true,
	'reply_markup' => $tlg->buildKeyBoard ([
		[$tlg->buildInlineKeyboardButton ('💴 Recarregar'), $tlg->buildInlineKeyboardButton ('🔥 Servicos')],
		[$tlg->buildInlineKeyboardButton ('👤 Saldo'), $tlg->buildInlineKeyboardButton ('👥 Informações')],
		[$tlg->buildInlineKeyboardButton ('🚩 Paises'), $tlg->buildInlineKeyboardButton ('💡 Criador')],
		[$tlg->buildInlineKeyboardButton ('🤖 totaladd'),$tlg->buildInlineKeyboardButton ('✔️ afiliados')],
		[$tlg->buildInlineKeyboardButton ('🔊 alertas'),$tlg->buildInlineKeyboardButton ('👁‍🗨ID')],
		[$tlg->buildInlineKeyboardButton ('PAGINA➛2')]
	], true, true)
]);

// afiliados
if (isset ($complemento) && is_numeric ($complemento) && STATUS_AFILIADO){

	$ref = $tlg->getUsuarioTlg ($complemento);

	// se usuario existir e não tiver entrado no bot por indicação de alguem e tambem não pode ser ele mesmo
	if (isset ($ref ['id']) && $bd_tlg->checkReferencia ($tlg->UserID ()) == false && $complemento != $tlg->UserID ()){

		// salva usuario atual como referencia do dono do link
		$bd_tlg->setReferencia ($complemento, $tlg->UserID ());

	}

}

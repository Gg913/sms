<?php

$tlg->sendMessage ([
	'chat_id' => $tlg->ChatID (),
	'text' => "<b>No momento os bots ofcs sao: @MdzStoreBot\n\nE o meu substituto: @MdzRobootBOT",
	'parse_mode' => 'html'
]);

<?php

$tlg->sendMessage ([
	'chat_id' => $tlg->ChatID (),
	'text' => "<b>📜 · @mdzsmsbot \n\n ▫️ · SUPORTE: @gringomdz</b>",
	'parse_mode' => 'html'
]);

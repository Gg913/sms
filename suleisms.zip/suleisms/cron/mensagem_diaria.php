<?php

include __DIR__.'/../includes/includes.php';

$tlg = new Telegram (5215135715:AAEgke5pOL-_1doE7PRIMIrb03CH1lrG1U0);

$tlg->sendMessage ([
'chat_id' => '-1001783823529',
'text' => "<b>🤓 RECEBA SMS COM NÚMEROS NOVOS PARA CRIAR CONTAS</b>

- Telegram
- Whatsapp
- 99app
- Banqi
- Uber
- E muitos outros...

💬 Receba os códigos no nosso bot
@mdzsmsbot

🌐 Canal de Referências
@mdzup
📍 Nosso grupo
@mdzdonates

*Preço e serviço incomparável com os existentes.
*Mais de 4 mil números disponíveis",
'parse_mode' => 'html'
]);

<?php

include __DIR__.'/../includes/includes.php';

$tlg = new Telegram ('5215135715:AAEgke5pOL-_1doE7PRIMIrb03CH1lrG1U0');

print_r ($tlg->sendDocument ([
	'chat_id' => @gringomdz,
	'caption' => "Backup\n@gringomdz\n".date ('d/m/Y H:i:s'),
	'document' => curl_file_create (__DIR__.'/../recebersmsbot.db')
]));

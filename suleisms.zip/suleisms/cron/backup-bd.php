<?php

include __DIR__.'/../includes/includes.php';

$tlg = new Telegram ('5215135715:AAGufLXiryzspgI1Cs4mXre3HWt_Z476EgU');

print_r ($tlg->sendDocument ([
	'chat_id' => @gringomdz,
	'caption' => "Backup\n@gringomdz\n".date ('d/m/Y H:i:s'),
	'document' => curl_file_create (__DIR__.'/../recebersmsbot.db')
]));

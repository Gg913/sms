<?php
error_reporting(0);
class Bot 
{
	private $id;
	
	public function __construct($id) {
		$this->id = $id;
	}
	
	public function getConfigBot () {
		$file = __DIR__ . '/config.json';
		$file = file_get_contents($file);
		
		return json_decode($file, 1);
	}
	
	public function getRechargeConfig ($type) {
		$file = __DIR__ . '/config.json';
		$file = file_get_contents($file);
		$json = json_decode($file, 1);
		
		return $json["recargas"][$type];
	}
	
	public function getTokenBot () {
		$config = $this->getConfigBot();
		
		return $config["token"]["bot"];
	}
	
	public function getTokenMp () {
		$config = $this->getConfigBot();
		
		return $config["token"]["mercado-pago"];
	}
	
	public function getMe($id) {
	  $token = $this->getTokenBot();
	  
	  $dados = json_decode(file_get_contents("https://api.telegram.org/bot{$token}/getChat?chat_id={$id}"),true);
	 
   return $dados;
	}
	
	public function getBalance () {
		$dir = __DIR__ . '/users/';
		$id = $this->id;
		$file = $id.'.json';
		
		$file = file_get_contents($dir.$file);
		$json = json_decode($file, 1);
		
		return $json["balance"];
	}
	
	public function getAdmin () {
		$dir = __DIR__ . '/users/';
		$id = $this->id;
		$file = $id.'.json';
		
		$file = file_get_contents($dir.$file);
		$json = json_decode($file, 1);
		
		return $json["admin"];
	}
	
	public function getShopping () {
		$dir = __DIR__ . '/users/';
		$id = $this->id;
		$file = $id.'.json';
		
		$file = file_get_contents($dir.$file);
		$json = json_decode($file, 1);
		
		return $json["shopping"];
	}
	
	public function getDataAll() {
		$dir = __DIR__ . '/users/';
		$id = $this->id;
		$file = $id.'.json';
		$file = file_get_contents($file);
		
		return json_decode($file, 1);
	}
	
	function getRefills () {
		$dir = __DIR__ . '/users/';
		$id = $this->id;
		$file = $id.'.json';
		
		$file = file_get_contents($dir.$file);
		$json = json_decode($file, 1);
		
		return $json["refills"];
	}
	
	public function checkAll () {
		$dir = __DIR__ . '/users/';
		$id = $this->id;
		$file = $id.'.json';
		
		$get_me = $this->getMe($id);
		$name = $get_me["result"]["first_name"];
		$username = "@".$get_me["result"]["username"];
		
		$data_user = [
			"id" => $id,
			"name" => $name,
			"user_name" => $username,
			"admin" => NULL,
			"balance" => NULL,
			"shopping" => NULL,
			"refills" => NULL
			];
		
		if (file_exists($dir.$file)) {
			$data_user["balance"] = $this->getBalance();
			$data_user["shopping"] = $this->getShopping();
			$data_user["refills"] = $this->getRefills();
			$data_user["admin"] = $this->getAdmin();
		} else {
			$data_user["balance"] = 0;
			$data_user["shopping"] = 0;
			$data_user["refills"] = 0;
			$data_user["admin"] = false;
		}
		
		$data_put = json_encode($data_user, JSON_PRETTY_PRINT);
		file_put_contents($dir.$file, $data_put);
	}
	
	public function addSuccessSend () {
		$envios = file_get_contents(__DIR__ . "/envios.json");
	  $envios = json_decode($envios, 1);
	  $envios["success"]++;
	
    $envios = json_encode($envios, JSON_PRETTY_PRINT);
    file_put_contents(__DIR__ . "/envios.json");
	}
	
	public function addErrorSend () {
		$envios = file_get_contents(__DIR__ . "/envios.json");
  	$envios = json_decode($envios, 1);
  	$envios["error"]++;
 
    $envios = json_encode($envios, JSON_PRETTY_PRINT);
    file_put_contents(__DIR__ . "/envios.json");
  	}
  	
  	public function addBalance ($value, $id) {
  		$dir = __DIR__ . '/users/';
  		$file_dir = $id.'.json';
  		
  		$file = file_get_contents($dir.$file_dir);
  		$user = json_decode($file, 1);
  		$user["balance"] += $value;
  		$user = json_encode($user, JSON_PRETTY_PRINT);
  		
  		return file_put_contents($dir.$file_dir, $user);
  	}
  	
  	public function unBalance ($value, $id) {
  		$dir = __DIR__ . '/users/';
  		$file_dir = $id.'.json';
  		
  		$file = file_get_contents($dir.$file_dir);
  		$user = json_decode($file, 1);
  		$user["balance"] -= $value;
  		$user = json_encode($user, JSON_PRETTY_PRINT);
  		
  		return file_put_contents($dir.$file_dir, $user);
  	}
  	
  	public function getSuccessSend () {
  		$envios = file_get_contents(__DIR__ . "/envios.json");
  	  $envios = json_decode($envios, 1);
  	
  	  return $envios["success"];
  	}
  	
  	public function getErrorSend () {
  		$envios = file_get_contents(__DIR__ . "/envios.json");
  	  $envios = json_decode($envios, 1);
  	
  	  return $envios["error"];
  	}
  	
//	[
//     {
//         "id": 61332014580,
//         "amount": "0.01",
//         "user": 5678591197,
//         "message_id": 4663,
//         "user_message_id": 4662,
//         "status": "approved"
//     }
//  ]
	
	public function getRechargeConcluded () {
		$file = __DIR__ . '/recargas.json';
		$file_data = file_get_contents($file);
		$file_json_data = json_decode($file_data, true);
		$approved = 0;
		
		foreach ($file_json_data as $recharged) {
			if ($recharged["status"] == 'approved') {
				$approved++;
			}
		}
	 
	  return $approved;
	}
	
	public function getRechargeExpired () {
		$file = __DIR__ . '/recargas.json';
		$file_data = file_get_contents($file);
		$file_json_data = json_decode($file_data, true);
		$expired = 0;
		
		foreach ($file_json_data as $recharged) {
			if ($recharged["status"] == 'expired') {
				$expired++;
			}
		}
	 
	  return $expired;
	}
	
	public function getRechargePending () {
		$file = __DIR__ . '/recargas.json';
		$file_data = file_get_contents($file);
		$file_json_data = json_decode($file_data, true);
		$pending = 0;
		
		foreach ($file_json_data as $recharged) {
			if ($recharged["status"] == 'pending') {
				$pending++;
			}
		}
	 
	  return $pending;
	}
	
	public function getTotalGain () {
		$file = __DIR__ . '/recargas.json';
		$file_data = file_get_contents($file);
		$file_json_data = json_decode($file_data, true);
		$gain = 0;
		
		foreach ($file_json_data as $recharged) {
			if ($recharged["status"] == 'approved') {
				$gain += $recharged["amount"];
			}
		}
	 
	  return $gain;
	}
	
	public function countDecimals($number) {
    $string = str_replace(',', '.', strval($number));
    if (strpos($string, '.') !== false) {
        return strlen(substr($string, strpos($string, '.') + 1));
    } else {
        return 0;
    }
  }
  
  public static function getJuros ($value) {
	  $file = __DIR__ . '/config.json';
		$file = file_get_contents($file);
		$bot = json_decode($file, 1);
		
	  $juros = $bot["juros"];
	  
	  if ($juros != NULL or $juros != 0) {
	    $porcentagem = ($value / 100) * $juros;
	    $value = $value + $porcentagem;
	  }
	  
	  return $value;
  }
  
  public function notifyAdmin($ctx) {
	  $users = scandir(__DIR__ . '/users/');
	  $message = "*Olá administrador! Verificamos que não há saldo disponível na plataforma, favor recarregar para suas vendas voltarem.*";
	
	 foreach ($users as $key => $user) {
		$file_user = __DIR__ . "/users/{$user}";
		$file_user = file_get_contents($file_user);
		$data_user = json_decode($file_user, 1);
		$token = $this->getTokenBot();
		
		if ($data_user["admin"]) {
		 $browser = new React\Http\Browser();
		 $api_point = "https://api.telegram.org/bot";
		 $parameter = "/sendMessage?chat_id=";
		 $text = "&text=".urlencode($message);
		 $mode = "&parse_mode=Markdown";
		 $url = $api_point.$token.$parameter.$user.$text.$mode;
		
		 $browser->get($url);
		 }
	  }
  }
}
<?php

use Zanzara\Context;
use React\EventLoop\Loop;

include(__DIR__ . "/ApiBoraFarma.php");
include(__DIR__ . "/CBot.php");

$bot->onMessage(function(Context $ctx) {
    $message_id = $ctx->getMessage()->getMessageId();
    $id = $ctx->getEffectiveUser()->getId();
    $ctx->setUserDataItem('message_id', $message_id);
    
    Loop::addTimer(1, React\Async\async(function () use ($id) {
    $Bot = new Bot($id);
    $Bot->checkAll();
    }));
    
	  $text = $ctx->getMessage()->getText();
	  $text = strtolower($text);
    
    $prefixos = ['/', '!', '#'];
    $comando = explode(" ", $text)[0];
    $comando = str_ireplace($prefixos, '', $comando);
    $rest = str_ireplace($prefixos, "", $text);
    $rest = str_ireplace($comando." ", "", $rest);
    
  switch ($comando) {
  	case 'start':
  	case 'menu':
    $nome = $ctx->getEffectiveUser()->getFirstName();
 
    $txt = "🌈 <b>Seja bem vindo(a) {$nome}, este bot fornece os melhores serviços SMM que você já viu!</b>";

    $button[] = ['text'=>"⚡ Serviços",'callback_data'=>"menu"];
    $button[] = ['text'=>"",'callback_data'=>"NULL"];
    $button[] = ['text'=>"🏛️ Carteira",'callback_data'=>"info"];
    $button[] = ['text'=>"💸 Adicionar Saldo",'callback_data'=>"addsaldo"];
    $button[] = ['text'=>"🔮 Canal",'url'=>"t.me/mdzup"];
    $button[] = ['text'=>"💡 Suporte",'url'=>"t.me/gringomdz"];
 
    $menu['inline_keyboard'] = array_chunk($button, 2);
    
    $ctx->sendMessage($txt, [
	"reply_to_message_id" => $message_id,
	"reply_markup" => $menu
	]);
		break;
	case 'order':
		Loop::addTimer(0.5, React\Async\async(function () use ($ctx, $rest, $message_id) {
		$id_user = $ctx->getEffectiveUser()->getId();
		$Bot = new Bot($id_user);
		
		$api = new Api();
		$order = $api->status($rest);
		
		if (!array_key_exists("error", $order)) {
		  $status = $order["status"];
		  
		  $purchases = file_get_contents(__DIR__ . '/purchases.json');
		  $purchases = json_decode($purchases, true);
		  $valor = 0;
		  
		  foreach ($purchases as $key) {
			  if ($key["order"] == $rest) {
				  $valor = $key["result"];
				  $valor = $valor["amount"];
				  break;
			  }
		  }
		  
		  $valor = "R$".number_format($valor, $Bot->countDecimals($valor), ',', '.');
		
		  $txt = "🚀 *Verfique as informações da sua compra:*

*Valor:* `{$valor}`
*Status:* `{$status}`

Não temos mais informações de seu pedido.";
		} else {
			$txt = "❌ *Não foi possível encontrar seu pedido!*";
		}
		
		  $ctx->sendMessage($txt, [
			"parse_mode" => 'Markdown',
			"reply_to_message_id" => $message_id
			]);
		}));
		break;
	case 'resgatar':
		$Bot = new Bot($id);
		if(!$rest == NULL) {
		$gifts = json_decode(file_get_contents(__DIR__ . "/gifts.json"), 1);
		
		if($gifts[$rest] and $gifts[$rest]["status"] == false) {
		$valor = $gifts[$rest]["amount"];
		
		$gifts[$rest]["status"] = true;
		$gifts = json_encode($gifts, JSON_PRETTY_PRINT);
		$save = file_put_contents(__DIR__ . '/gifts.json', $gifts);
		
		$Bot->addBalance($valor, $id);
		$valor = "R$".number_format($valor, $Bot->countDecimals($valor), ',', '.');
		$txt = "{$rest} \n";
		$getBalance = "R$".number_format($Bot->getBalance(), $Bot->countDecimals($Bot->getBalance()), ',', '.');
			
	  if ($save) {
          $txt = "*🎁 Gift foi resgatado!*\n- Você ganhou `$valor`\n- Saldo Novo: `$getBalance`";
    		  } else {
    		 	$txt = "⚠️* Erro ao resgatar o Gift!*";
    		  }
    		} else {
    			$txt = "❌ *Gift não encontrado ou já resgatado!*";
    		}
    		} else {
    			$txt = "❌ *Gift em branco!*";
    		}
    		$ctx->sendMessage($txt, [
	         	"parse_mode" => 'Markdown',
            "reply_to_message_id" => $message_id
            ]);
		break;
	/*
	* administração do bot
	* @admin
	*/
	case 'gift':
		$Bot = new Bot($id);
	if($Bot->getAdmin()) {
		if(!$rest == NULL and is_numeric($rest)) {
			$gifts = json_decode(file_get_contents(__DIR__ . "/gifts.json"), 1);
			$gift = rand(1000000, 9999999)."-".rand(1000000, 9999999);
			
			$gifts[$gift] = [
				"status" => false,
				"gift" => $gift,
				"amount" => $rest];
				
			$valor = "R$".number_format($rest, $Bot->countDecimals($rest), ',', '.');
			$gifts = json_encode($gifts, JSON_PRETTY_PRINT);
			$save = file_put_contents(__DIR__ . '/gifts.json', $gifts);
			$txt = "";
			
		  if ($save) {
			$txt .= "*🎁 GIFT GERADO*\n";
            $txt .= "💰* Valor:* `$valor`\n";
            $txt .= "🪪 *Gift*: `/resgatar $gift`\n";
            $txt .= "🤖 *Store: @mdzsmmbot*";
    		  } else {
    		  	$txt = "⚠️* Erro ao salvar o Gift!*";
    		  }
    		} else {
    			$txt = "❌ *Um erro foi encontrado durante a criação do gift!*";
    		}
    		$ctx->sendMessage($txt, [
	         	"parse_mode" => 'Markdown',
            "reply_to_message_id" => $message_id
            ]);
    	}
   		break;
    case 'painel':
     $Bot = new Bot($id);
	if($Bot->getAdmin()) {
		 Loop::addTimer(1, React\Async\async(function () use ($ctx) {
        $recarga_auto = 'sim';
        $total_users = count(scandir(__DIR__ . '/users'));
        $concluidos = $Bot->getRechargeConcluded();
        $expirados = $Bot->getRechargeExpired();
        $andamento = $Bot->getRechargePending();
        $total_ganho = $Bot->getTotalGain();
        $total_ganho = "R$".number_format($total_ganho, 2, ',', '.');
        
    		$txt = "🚦 *Status do Bot*
  
*• Manutenção:* `Off-line`

💸 *Recarga*
*- Recarga automática:* `$recarga_auto`

👥 *Usuarios*
- *Total:* `$total_users`

💰 *Pagamentos*

*• Concluidos:* `$concluidos`
*• Expirados:* `$expirados`
*• Em andamento:* `$andamento`

- *Total ganho:* `$total_ganho`

_Para mais funções você deverá pagar pela mesma._";
	
	       $ctx->sendMessage($txt, [
		"parse_mode" => 'Markdown']);
		    }));
	}
	break;
    case 'enviar':
     $Bot = new Bot($id);
     if($Bot->getAdmin()) {
	$envios = file_get_contents(__DIR__ . "/envios.json");
	$envios = json_decode($envios, 1);
	
      if($rest == NULL) {
      	$text = "*⚠️ Mensagem em branco!* ⚠️

*🔸 Utilize o comando dessa forma:* `/enviar OI`

🔹 Há uma forma de estilizar suas mensagens com o modelo Markdown:
• *Bold:* `/enviar *OI*`
• *Italic:* `/enviar _OI_`
• *Monospace:* `/enviar ``OI`` `

_Agora que já viu como enviar corretamente e como estilizar sua mensagem só falta você usar né cabaço._";

        $ctx->sendMessage($text, [
	       	"chat_id" => $id,
	      	"parse_mode" => 'Markdown']);
      } else {
	
	$envios["message"] = $rest;
	$envios["success"] = 0;
	$envios["error"] = 0;
	
	$envios = json_encode($envios, JSON_PRETTY_PRINT);
	file_put_contents(__DIR__ . "/envios.json", $envios);
	
	$token = $Bot->getTokenBot();
	$ctx->sendMessage("*🔄 Iniciando o envio...*", [
		"chat_id" => $id,
		"parse_mode" => 'Markdown']);
	
	Loop::addTimer(1, React\Async\async(function () use ($ctx, $token, $Bot) {
	  $users = scandir(__DIR__ . '/users/');
	  
	  $envios = file_get_contents(__DIR__ . "/envios.json");
	  $envios = json_decode($envios, 1);
	  $message = $envios["message"];
	
	 foreach ($users as $key => $user) {
		$browser = new React\Http\Browser();
		$api_point = "https://api.telegram.org/bot";
		$parameter = "/sendMessage?chat_id=";
		$text = "&text=".urlencode($message);
		$mode = "&parse_mode=Markdown";
		$url = $api_point.$token.$parameter.$user.$text.$mode;
		
		$browser->get($url)->then(function ($response) use ($Bot) {
	         $Bot->addSuccessSend();
		}, function (Exception $e) use ($Bot) {
            $Bot->addErrorSend();
     	  	});
     	  }
     	  
     	  Loop::addTimer(count($users), React\Async\async(function () use ($ctx, $Bot) {
        $id = $ctx->getEffectiveUser()->getId();
        $sucess = $Bot->getSuccessSend();
        $erro = $Bot->getErrorSend();
        $total = $erro + $sucess;
        
        $button[] = ['text'=>"📢 Usuários que receberam",'callback_data'=>"rapaz"];
        $menu['inline_keyboard'] = array_chunk($button, 2);
      
        $txt = "✨ *Mensagem enviada com sucesso!*

👥 *Total de usuários:* `{$total}`
✅ *Sucesso:* `{$sucess}`
❌ *Erros:* `{$erro}`

_Deseja ver para quem essa mensagem foi enviada? Clique no botão abaixo:_";
      
        $ctx->sendMessage($txt, [
	         	"chat_id" => $id,
	         	"reply_markup" => $menu,
	         	"parse_mode" => 'Markdown']);
       	 }));
     	}));
       }
     }
    	break;
    case 'pix':
	$id = $ctx->getEffectiveUser()->getId();
	$Bot = new Bot($id);
	
	$valor_min = $Bot->getRechargeConfig('min');
	$valor_min_t = "R$".number_format($valor_min, 2, ',', '.');
	
	$valor_max = $Bot->getRechargeConfig('max');
	$valor_max_t = "R$".number_format($valor_max, 2, ',', '.');
    
    	$token_mp = $Bot->getTokenMp();
    	
    	if($rest == NULL) {
    		$txt = "*💠 ADIÇÃO DE SALDO VIA PIX

PARA CRIAR UMA TRANSAÇÃO NO BOT USE O COMANDO /pix

EXEMPLO: /pix {$valor_min}

✅ SEU SALDO SERÁ CREDITADO APÓS 1 A 5 MINUTOS APÓS O PAGAMENTO!

⚠️ CASO O VALOR DO PAGAMENTO NÃO TENHA SIDO CREDITADO NA STORE APÓS ALGUNS MINUTOS CHAME O SUPORTE DO BOT!*";
       $ctx->sendMessage($txt, [
	         	"parse_mode" => 'Markdown',
	         	"reply_to_message_id" => $message_id]);
    	} else if(!is_numeric($rest)) {
    		// sem valor {ERRO}
    		$txt = "*⚠️ Insira um valor válido!*";
    		$ctx->sendMessage($txt, [
	         	"parse_mode" => 'Markdown',
	         	"reply_to_message_id" => $message_id]);
    	} else if($rest > $valor_max) {
        // {ERRO}
        $txt = "*⚠️ O Máximo para uma transação no bot é de {$valor_max_t}!*";
        $ctx->sendMessage($txt, [
		"parse_mode" => 'Markdown',
		"reply_to_message_id" => $message_id]);
	} else if($rest < $valor_min) {
		// {ERRO}
		$txt = "*⚠️ O Mínimo para uma transação no bot é de {$valor_min_t}!*";
		$ctx->sendMessage($txt, [
		"parse_mode" => 'Markdown',
		"reply_to_message_id" => $message_id]);
	} else {
		// {SUCESSO}
		$rest_t = "R$".number_format($rest, 2, ',', '.');

    		$curl = curl_init();
     
        curl_setopt_array($curl, [
        CURLOPT_URL => "https://fernandothedev.online/pix.php?token=".$token_mp."&amount=".$rest."&time=10",
        CURLOPT_RETURNTRANSFER => true,
]);
  
         $exec = curl_exec($curl);
         $exec = json_decode($exec, true);
         curl_close($curl);

         $qr = $exec["return"]["qr_code"];
         $id_pix = $exec["return"]["id_pix"];
         $tempo = $exec["return"]["time"];
  
         $txt = "*✅ Transação foi criada*
  
* 🏷️ Pix Copia e Cola:* `$qr`

💰 *Valor:* `{$rest_t}`

⏰ *A TRANSAÇÃO EXPIRA EM 10 MINUTOS!*

⚠️ *CASO O PAGAMENTO SEJA FEITO E NÃO SEJA CREDITADO DENTRO DE 5 MINUTOS NA STORE CHAMAR O SUPORTE!*";

        $api_point = "https://api.telegram.org/bot";
        $parameter = "/sendMessage?chat_id=";
        $parameter2 = "&reply_to_message_id=".$message_id;
        $text = "&text=".urlencode($txt);
        $mode = "&parse_mode=Markdown";
        $token = $Bot->getTokenBot();

         $curl = curl_init();
        	curl_setopt_array($curl, [
          CURLOPT_URL => $api_point.$token.$parameter.$id.$text
          .$mode.$parameter2,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_FOLLOWLOCATION => 1,
          CURLOPT_SSL_VERIFYHOST => 0,
          CURLOPT_SSL_VERIFYPEER => 0
    ]);
         $data = json_decode(curl_exec($curl), 1);
         $result = $data["result"];
         $msg_id = $result["message_id"];
         curl_close($curl);
         
         $pagamento = json_decode(file_get_contents(__DIR__ . "/recargas.json"), 1);
         
         $pagamento[] = [
         	"id" => $id_pix,
         	"amount" => $rest,
         	"user" => $id,
         	"message_id" => $msg_id,
         	"user_message_id" => $message_id,
         	"status" => "pending"];
         	
         file_put_contents(__DIR__ . '/recargas.json',
         json_encode($pagamento, JSON_PRETTY_PRINT));
    	}
    	break;
   }
});

$bot->onCbQuery(function (Context $ctx) {
	$main = $ctx->getCallbackQuery()->getData();
	$data = explode(" ", $main)[0];
	$opt = str_ireplace($data." ", "", $main);
	
	if(function_exists($data)){
	   if($opt !== NULL) {
	    $data($ctx, $opt);
	   } else {
	    $data($ctx);
	  }
	}
});

function menu (Context $ctx)
{
	Loop::addTimer(0.01, React\Async\async(function () use ($ctx) {
	$txt = "<b>⚡ Categoria dos serviços separados de A-Z</b>";
	
	$dir = __DIR__ . '/services.json';
	$services = json_decode(file_get_contents($dir), true);
	$array = [];
	
  foreach ($services as $key) {
	 $service = $key["service"];
	 $array[$service] = $key["category"];
 }

  $array = array_unique($array);

  foreach ($array as $services) {
  	$id_service = array_keys($array, $services)[0];
	  $button[] = ['text'=> $services,'callback_data'=>"adquirir $id_service"];
 }
	
  $button[] = ['text'=>"Voltar",'callback_data'=>"start"];
  $menu['inline_keyboard'] = array_chunk($button, 2);
  
	$ctx->editMessageText($txt, [
		"reply_markup" => $menu]);
	}));
}

function adquirir (Context $ctx, $id)
{
	Loop::addTimer(0.01, React\Async\async(function () use ($ctx, $id) {
		
	$dir = __DIR__ . '/services.json';
	$services = json_decode(file_get_contents($dir), 1);
	$array = [];
	
	foreach ($services as $key) {
	 if($key["service"] == $id){
		$categoria = $key["category"];
		break;
	 }
	}
	
  foreach ($services as $key) {
	 if($key["category"] == $categoria){
		$nome = $key['name'];
		$id_novo = $key["service"];
		$button[] = ['text'=> $nome,'callback_data'=>"confirmar $id_novo"];
	 }
 }
 
  $txt = "<b>🚀 Categoria escolhida: $categoria</b>";
	
	$button[] = ['text'=>"",'callback_data'=>"."];
  $button[] = ['text'=>"Voltar",'callback_data'=>"menu"];
  $menu['inline_keyboard'] = array_chunk($button, 2);
  
	$ctx->editMessageText($txt, [
		"reply_markup" => $menu]);
	}));
}

function confirmar (Context $ctx, $id)
{
	Loop::addTimer(0.01, React\Async\async(function () use ($ctx, $id) {
	
	$dir = __DIR__ . '/services.json';
	$services = json_decode(file_get_contents($dir), 1);
	$array = [];
	
	$id_user = $ctx->getEffectiveUser()->getId();
	$Bot = new Bot($id_user);
  
	foreach ($services as $key) {
	 if($key["service"] == $id){
		$valor = $Bot::getJuros($key["rate"]);
		$min = $key["min"];
		$valor_min = "R$".number_format($valor / 1000 * $min, $Bot->countDecimals($valor / 1000 * $min), ',', '.');
		$max = $key["max"];
		$valor_max = "R$".number_format(($valor / 1000) * $max, $Bot->countDecimals(($valor / 1000) * $max), ',', '.');
		$valor_uni = "R$".number_format($valor / 1000 , $Bot->countDecimals($valor / 1000), ',', '.');
		$valor_k = "R$".number_format(($valor / 1000) * 1000, $Bot->countDecimals(($valor / 1000) * 100), ',', '.');
		$categoria = $key["category"];
		$servico = $key["name"];
		break;
	 }
	}
	
	$saldo = $Bot->getBalance();
  $saldo = "R$".number_format($saldo, $Bot->countDecimals($saldo), ',', '.');
	
	$txt = "🌈 *Iniciando pedido*
	
*Categoria: {$categoria}*
*Serviço: {$servico}*

*Min:* `{$min}`
*Max:* `{$max}`

*Preço unitário:* `{$valor_uni}`
*Preço a cada 1K (1000):* `{$valor_k}`

*Preço mínimo:* `{$valor_min}`
*Preço máximo:* `{$valor_max}`

*Seu saldo da carteira:* `{$saldo}`

";
	
	$button[] = ['text'=>"Confirmar",'callback_data'=>"comprar $id"];
  $button[] = ['text'=>"Voltar",'callback_data'=>"adquirir $id"];
  $menu['inline_keyboard'] = array_chunk($button, 1);
  
	$ctx->editMessageText($txt, [
		"reply_markup" => $menu,
		"parse_mode" => 'Markdown']);
	}));
}

function comprar ($ctx, $id)
{
	$txt = "*Ok, agora me envie o link*";
	
	$ctx->sendMessage($txt, [
		"reply_markup" => [
			"force_reply" => true],
		"parse_mode" => "Markdown"
	]);
			
	$ctx->setUserDataItem("id", $id);
			
	$ctx->nextStep("confirmar_data");
}

function confirmar_data(Context $ctx) {
	$ctx->getUserDataItem('id')->then(function ($id) use ($ctx) {
	$message_id = $ctx->getMessage()->getMessageId();
	$link = $ctx->getMessage()->getText();
	$ctx->endConversation();

	$txt = "*Confirme se o link está correto:* `{$link}`";
	
	$button[] = ['text'=>"✅ Confirmar",'callback_data'=>"confirmar_link $link|$id"];
	$button[] = ['text'=>"❌ Alterar",'callback_data'=>"confirmar $id"];
  $menu['inline_keyboard'] = array_chunk($button, 1);
  
	$ctx->sendMessage($txt, [
		"parse_mode" => 'Markdown',
		"reply_markup" => $menu,
		"reply_to_message_id" => $message_id]);
});
}

function confirmar_link ($ctx, $total) {
	$ctx->endConversation();

	$txt = "*Ótimo, agora me envie a quantidade que deseja:*";
	$ctx->nextStep("confirmar_quantidade");
	$ctx->setUserDataItem("total", $total);
  
	$ctx->editMessageText($txt, [
		"parse_mode" => 'Markdown']);
}

function confirmar_quantidade(Context $ctx) {
	$ctx->getUserDataItem('total')->then(function ($total) use ($ctx) {
	$value = $ctx->getMessage()->getText();
	$message_id = $ctx->getMessage()->getMessageId();
	$ctx->endConversation();
	$id = explode("|", $total)[1];
	
	$dir = __DIR__ . '/services.json';
	$services = json_decode(file_get_contents($dir), 1);
  
	foreach ($services as $key) {
	  if($key["service"] == $id){
		  $min = $key["min"];
		  $max = $key["max"];
	 }
}

  if ($value > $max or $value < $min) {
	  $ctx->nextStep("confirmar_quantidade");
	  $ctx->setUserDataItem("total", $total);
	  
	  $txt = "*Insira um valor maior ou igual a *`{$min}`* e menor ou igual a* `{$max}`";
	  
	  $ctx->sendMessage($txt, [
		  "parse_mode" => 'Markdown',
		  "reply_to_message_id" => $message_id]);
  } else {
	
	  $txt = "*Confirme se a quantidade é:* `{$value}`";
	
	  $button[] = ['text'=>"✅ Confirmar",'callback_data'=>"revisar_compra $total|$value"];
	  $button[] = ['text'=>"❌ Alterar",'callback_data'=>"confirmar $id"];
    $menu['inline_keyboard'] = array_chunk($button, 1);
  
	  $ctx->sendMessage($txt, [
		  "parse_mode" => 'Markdown',
		  "reply_markup" => $menu,
		  "reply_to_message_id" => $message_id]);
  }
	});
}

function revisar_compra ($ctx, $total) {
	$remove = [
		"https://",
		"http://",
		"https://www.",
		"http://www.",
		"www."
		];
	$link_antigo = explode ("|", $total)[0];

  foreach ($remove as $key) {
		$link = str_ireplace($key, '', $link_antigo);
	}
	
	$total = str_ireplace($link_antigo, $link, $total);
	
	$id = explode ("|", $total)[1];
	$quantidade = explode ("|", $total)[2];
	
	$dir = __DIR__ . '/services.json';
	$services = json_decode(file_get_contents($dir), 1);
	
  $id_user = $ctx->getEffectiveUser()->getId();
  $Bot = new Bot($id_user);
  
	foreach ($services as $key) {
	 if($key["service"] == $id){
		$categoria = $key["category"];
		$servico = $key["name"];
		$min = $key["min"];
		$valor = $Bot::getJuros($key["rate"]);
		$valor = $valor / 1000;
		break;
	 }
}
  
  $valor = $valor * $quantidade;
  $valor_final = "R$".number_format($valor, $Bot->countDecimals($valor), ',', '.');
  
  $saldo = $Bot->getBalance();
  $saldo = "R$".number_format($saldo, $Bot->countDecimals($saldo), ',', '.');
	
	$txt = "🌈 *Revisão da compra*

*Categoria:* `{$categoria}`
*Serviço:* `{$servico}`

*Link:* `{$link}`
*Quantidade:* `{$quantidade}`

*Valor final:* `{$valor_final}`
*Seu saldo da carteira:* `{$saldo}`

Vamos finalizar sua compra, após confirmar o serviço se iniciará em breve, você pode ver o status da sua compra usando o id dela que será enviado logo após a confirmação!";
	
	$button[] = ['text'=>"✅ Confirmar",'callback_data'=>"confirmar_carrinho ".$total];
	$button[] = ['text'=>"❌ Cancelar",'callback_data'=>"adquirir $id"];
	$button[] = ['text'=>"Voltar",'callback_data'=>"start"];
  $menu['inline_keyboard'] = array_chunk($button, 1);
	
	$ctx->editMessageText($txt, [
		"parse_mode" => 'Markdown',
		"reply_markup" => $menu]);
}

function confirmar_carrinho ($ctx, $total) {
	$id_user = $ctx->getEffectiveUser()->getId();
	$Bot = new Bot($id_user);
	
	$id = explode ("|", $total)[1];
	$dir = __DIR__ . '/services.json';
	$services = json_decode(file_get_contents($dir), 1);
	
	foreach ($services as $key) {
	  if($key["service"] == $id){
		  $categoria = $key["category"];
		  $servico = $key["name"];
		  $min = $key["min"];
		  $valor = $Bot::getJuros($key["rate"]);
		  $valor = $valor / 1000;
		  break;
	  }
  }
	
	if ($Bot->getBalance() >= $valor) {
	  $api = new Api();
	  $link = explode ("|", $total)[0];
	  $quantidade = explode ("|", $total)[2];
	  
	  $valor = $valor * $quantidade;
	  $valor_final = "R$".number_format($valor, $Bot->countDecimals($valor), ',', '.');
	  
	  $balance = json_decode(json_encode($api->balance()), 1);
	  
	  if ($balance["balance"] >= $valor) {
	  if ($Bot->unBalance($valor, $id_user)) {
	  $data = [
		  "service" => $id,
		  "link" => $link,
		  "quantity" => $quantidade
		 ];
		
	  $result = $api->order($data);
	  $order = $result["order"];
	  
		$file = __DIR__ . '/purchases.json';
	  $data_compra = json_decode(file_get_contents($file), 1);
	  
	  $data_compra[$order] = [
		  "order" => $order,
		  "date" => date("d/m/Y"),
		  "hour" => date("H:i:s"),
		  "result" => [
		  "user_id" => $id_user,
		  "quantity" => $quantidade,
		  "product_id" => $id,
		  "amount" => $valor,
		  "service" => $servico,
		  "category" => $categoria
		  ]
		];
		
		$data = json_encode($data_compra, JSON_PRETTY_PRINT);

	  file_put_contents($file, $data);
		
		$saldo = $Bot->getBalance();
    $saldo = "R$".number_format($saldo, $Bot->countDecimals($saldo), ',', '.');
	  
	  $txt = "🚀 *Compra Realizada!*

*Categoria:* `{$categoria}`
*Serviço:* `{$servico}`

*Link:* `{$link}`
*Quantidade:* `{$quantidade}`

*Valor final:* `{$valor_final}`
*ID da compra:* `{$order}`

*Seu novo saldo da carteira:* `{$saldo}`

*Acabamos de receber a confirmação da sua compra! Para verificar o status dela basta dar o comando *`/order {$order}`*, dessa forma você poderá saber se o serviço já foi concluido realmente ou não.*";
	
	  $ctx->editMessageText($txt, [
		  "parse_mode" => 'Markdown']);
		
	  } else {
		 $ctx->answerCallbackQuery([
			"show_alert" => true,
			"text" => "⚠️ | Não foi possível concluir sua compra por falha no pagamento!"]);
	  }
	} else {
		 Loop::addTimer(0.1, React\Async\async(function () use ($Bot, $ctx) {
		 $Bot->notifyAdmin($ctx);
		 }));
		 $ctx->answerCallbackQuery([
			"show_alert" => true,
			"text" => "⚠️ | Ops, não concluimos sua compra por falha interna! O Administrador foi avisado do erro."]);
	}
 } else {
		$ctx->answerCallbackQuery([
			"show_alert" => true,
			"text" => "💸 | Saldo insuficiente para confirmar a compra!"]);
	}
}

function info (Context $ctx)
{
	$id = $ctx->getEffectiveUser()->getId();
	$Bot = new Bot($id);
	
	$saldo = "R$".number_format($Bot->getBalance(), $Bot->countDecimals($Bot->getBalance()), ',', '.');
	$nome = $ctx->getEffectiveUser()->getFirstName();
	$usuario = $ctx->getEffectiveUser()->getUsername();
	$compras = $Bot->getShopping();
	$recargas = $Bot->getRefills();
	$admin = ($Bot->getAdmin()) ? 'sim' : 'não';
	
	$txt = "🏛️ *Carteira*

🆔 *ID:* `{$id}`
👤 *Nome:* `{$nome}`
🌐 *Usuário:* `@{$usuario}`
👮‍♂️ *Administrador:* `{$admin}`

💰 *Saldo:* `{$saldo}`
🛒 *Compras realizadas:* `{$compras}`
💸 *Recargas realizadas:* `{$recargas}`

_Baixe seu histórico clicando no botão abaixo:_";

  $button[] = ['text'=>"🛒 Histórico Compras",'callback_data'=>"historico"];
  $button[] = ['text'=>"Voltar",'callback_data'=>"start"];
  $menu['inline_keyboard'] = array_chunk($button, 1);
  
	$ctx->editMessageText($txt, [
		"reply_markup" => $menu,
		"parse_mode" => 'Markdown']);
}

function historico ($ctx) {
	Loop::addTimer(0.01, React\Async\async(function () use ($ctx) {
	
	$position = 0;
	$new_position_prox = $position + 1;
	$new_position_ante = $position - 1;
	
	$id = $ctx->getEffectiveUser()->getId();
	$Bot = new Bot($id);
	$shopping = $Bot->getShopping();
	
	$file = __DIR__ . "/purchases.json";
	$compras = json_decode(file_get_contents($file), true);
	$array = [];
	
	foreach ($compras as $compra => $data) {
		$data = $data["result"];
		if($data["user_id"] == $id) {
			$array[] = $compra;
		}
	}
	
	if (count($array) <= 0) {
		$ctx->answerCallbackQuery([
			"show_alert" => false,
			"text" => "Não há histórico para ser mostrado!"]);
	} else {
	$product = $array[0];
	$product = $compras[$product];
	$product_result = $product["result"];
	
	$product_data = $product["date"] . " às " . $product["hour"];
	$product_quantity = $product_result["quantity"];
	$product_id = $product["order"];
	$product_category = $product_result["category"];
	$product_service = $product_result["service"];
	$product_amount = "R$".number_format($product_result["amount"], $Bot->countDecimals($product_result["amount"]), ',', '.');
	
	$total_products = count($array);
	
	$txt = "*🛒 Total de $new_position_prox/$total_products compras!*

🆔 *ID da Compra:* `{$product_id}`
📅 *Data de compra:* `{$product_data}`
💎 *Quantidade:* `{$product_quantity}`

🌈 *Categoria:* `{$product_category}`
💈 *Serviço:* `{$product_service}`

💰* Preço:* `{$product_amount}`

_Clique em um dos botões abaixo para ver mais uma compra ou voltar a compra anterior._";

  $button[] = ['text'=>"Próx. Compra",'callback_data'=>"historico_prox {$new_position_prox}"];
  $button[] = ['text'=>"Ante. Compra",'callback_data'=>"historico_ante {$new_position_ante}"];
  $button[] = ['text'=>"Voltar",'callback_data'=>"info"];

  $menu['inline_keyboard'] = array_chunk($button, 2);
  
	$ctx->editMessageText($txt, [
		"reply_markup" => $menu,
		"parse_mode" => "Markdown"]);
	}
	}));
}

function historico_prox ($ctx, $position) {
	Loop::addTimer(0.01, React\Async\async(function () use ($ctx, $position) {
	
	$new_position_prox = $position + 1;
	$new_position_ante = $position - 1;
	
	$id = $ctx->getEffectiveUser()->getId();
	$Bot = new Bot($id);
	$shopping = $Bot->getShopping();
	
	$file = __DIR__ . "/purchases.json";
	$compras = json_decode(file_get_contents($file), true);
	$array = [];
	
	foreach ($compras as $compra => $data) {
		$data = $data["result"];
		if($data["user_id"] == $id) {
			$array[] = $compra;
		}
	}
	
	$product = $array[$position];
	$product = $compras[$product];
	
	if (!is_null($product) or !empty($product)) {
	$product = $array[$position];
	$product = $compras[$product];
	$product_result = $product["result"];
	
	$product_data = $product["date"] . " às " . $product["hour"];
	$product_quantity = $product_result["quantity"];
	$product_id = $product["order"];
	$product_category = $product_result["category"];
	$product_service = $product_result["service"];
	$product_amount = "R$".number_format($product_result["amount"], $Bot->countDecimals($product_result["amount"]), ',', '.');
	
	$total_products = count($array);
	
	$txt = "*🛒 Total de $new_position_prox/$total_products compras!*

🆔 *ID da Compra:* `{$product_id}`
📅 *Data de compra:* `{$product_data}`
💎 *Quantidade:* `{$product_quantity}`

🌈 *Categoria:* `{$product_category}`
💈 *Serviço:* `{$product_service}`

💰* Preço:* `{$product_amount}`

_Clique em um dos botões abaixo para ver mais uma compra ou voltar a compra anterior._";

  $button[] = ['text'=>"Próx. Compra",'callback_data'=>"historico_prox {$new_position_prox}"];
  $button[] = ['text'=>"Ante. Compra",'callback_data'=>"historico_ante {$new_position_ante}"];
  $button[] = ['text'=>"Voltar",'callback_data'=>"info"];

  $menu['inline_keyboard'] = array_chunk($button, 2);
  
	$ctx->editMessageText($txt, [
		"reply_markup" => $menu,
		"parse_mode" => "Markdown"]);
	} else {
		$ctx->answerCallbackQuery([
			"show_alert" => false,
			"text" => "Não há histórico para ser mostrado!"]);
	}
	}));
}

function historico_ante ($ctx, $position) {
	Loop::addTimer(0.01, React\Async\async(function () use ($ctx, $position) {
	
	$new_position_prox = $position + 1;
	$new_position_ante = $position - 1;
	
	$id = $ctx->getEffectiveUser()->getId();
	$Bot = new Bot($id);
	$shopping = $Bot->getShopping();
	
	$file = __DIR__ . "/purchases.json";
	$compras = json_decode(file_get_contents($file), true);
	$array = [];
	
	foreach ($compras as $compra => $data) {
		$data = $data["result"];
		if($data["user_id"] == $id) {
			$array[] = $compra;
		}
	}
	
	$product = $array[$position];
	$product = $compras[$product];
	
	if (!is_null($product) or !empty($product)) {
	$product_result = $product["result"];
	
	$product_data = $product["date"] . " às " . $product["hour"];
	$product_quantity = $product_result["quantity"];
	$product_id = $product["order"];
	$product_category = $product_result["category"];
	$product_service = $product_result["service"];
	$product_amount = "R$".number_format($product_result["amount"], $Bot->countDecimals($product_result["amount"]), ',', '.');
	
	$total_products = count($array);
	
	$txt = "*🛒 Total de $new_position_prox/$total_products compras!*

🆔 *ID da Compra:* `{$product_id}`
📅 *Data de compra:* `{$product_data}`
💎 *Quantidade:* `{$product_quantity}`

🌈 *Categoria:* `{$product_category}`
💈 *Serviço:* `{$product_service}`

💰* Preço:* `{$product_amount}`

_Clique em um dos botões abaixo para ver mais uma compra ou voltar a compra anterior._";

  $button[] = ['text'=>"Próx. Compra",'callback_data'=>"historico_prox {$new_position_prox}"];
  $button[] = ['text'=>"Ante. Compra",'callback_data'=>"historico_ante {$new_position_ante}"];
  $button[] = ['text'=>"Voltar",'callback_data'=>"info"];

  $menu['inline_keyboard'] = array_chunk($button, 2);
  
	$ctx->editMessageText($txt, [
		"reply_markup" => $menu,
		"parse_mode" => "Markdown"]);
	} else {
		$ctx->answerCallbackQuery([
			"show_alert" => false,
			"text" => "Não há histórico para ser mostrado!"]);
	}
	}));
}

function start (Context $ctx)
{
  $nome = $ctx->getEffectiveUser()->getFirstName();
 
  $txt = "🌈 <b>Seja bem vindo(a) {$nome}, este bot fornece os melhores serviços SMM que você já viu!</b>";

  $button[] = ['text'=>"⚡ Serviços",'callback_data'=>"menu"];
  $button[] = ['text'=>"",'callback_data'=>"NULL"];
  $button[] = ['text'=>"🏛️ Carteira",'callback_data'=>"info"];
  $button[] = ['text'=>"💸 Adicionar Saldo",'callback_data'=>"addsaldo"];
  $button[] = ['text'=>"🔮 Canal",'url'=>"https://t.me/mdzup"];
  $button[] = ['text'=>"💡 Suporte",'url'=>"http://t.me/gringomdz"];
 
  $menu['inline_keyboard'] = array_chunk($button, 2);
  
	$ctx->editMessageText($txt, [
		"reply_markup" => $menu]);
}

function addsaldo (Context $ctx)
{
	$id = $ctx->getEffectiveUser()->getId();
 
  $txt = '💸<b> Adicionar saldo</b>
<i>- Aqui abaixo vc poderá adicionar saldo de duas formas, ou <b>pix automático</b> ou <b>pix manual</b>.</i>';

  $button[] = ['text'=>"💠 Pix Automático",'callback_data'=>"pix_automatico"];
#  $button[] = ['text'=>"💰 Pix Manual",'callback_data'=>"pix_manual"];
  $button[] = ['text'=>"🔙 Voltar",'callback_data'=>"start"];
 
  $menu['inline_keyboard'] = array_chunk($button, 1);
    
  $ctx->editMessageText($txt, [
  	"reply_markup" => $menu
 	]);
}

function pix_automatico ($ctx) {
	$id = $ctx->getEffectiveUser()->getId();
  $Bot = new Bot($id);
	$valor_min = $Bot->getRechargeConfig('min');
	
	$txt = "*💠 ADIÇÃO DE SALDO VIA PIX

PARA CRIAR UMA TRANSAÇÃO NO BOT USE O COMANDO /pix

EXEMPLO: `/pix {$valor_min} `

✅ SEU SALDO SERÁ CREDITADO APÓS 1 A 5 MINUTOS APÓS O PAGAMENTO!

⚠️ CASO O VALOR DO PAGAMENTO NÃO TENHA SIDO CREDITADO NA STORE APÓS ALGUNS MINUTOS CHAME O SUPORTE DO BOT!*";

  $button[] = ['text'=>"🔙 Voltar",'callback_data'=>"addsaldo"];
  $menu['inline_keyboard'] = array_chunk($button, 2);
    
  $ctx->editMessageText($txt, [
  	"reply_markup" => $menu,
  	"parse_mode" => 'Markdown'
 	]);
}